// ------ Libraries and Definitions ------
#include "simpletools.h"

// ------ Global Variables and Objects ------
serial *serial_lcd;



// ------ Main Program ------
int main()
{
  serial_lcd  = serial_open(12, 12, 0, 19200);
  // Connecter la diode sur P1
  // Connecter l'interrupteur reed sur P0
  high(0);
  low(1);
  // Connecter le LCD sur P12 et le rouge sur P40, le noir sur P39
  writeChar(serial_lcd, 22);
  pause(5);
  writeChar(serial_lcd, 12);
  pause(5);
  dprint(serial_lcd, "Bonjour Quentin");
  writeChar(serial_lcd, 215);
  writeChar(serial_lcd, 214);
  writeChar(serial_lcd, 223);
  pause(2000);
  writeChar(serial_lcd, 12);
  pause(5);
  dprint(serial_lcd, "Test connexion");
  pause(2000);
  // Effacer l'ecran
  writeChar(serial_lcd, 12);
  pause(5);
  while(1) {
    // Tester P1 si le courant passe
    if (input(1) == 1) {
      // Afficher a la position 0,0 du LCD
      writeChar(serial_lcd, (128 + (constrainInt(0, 0, 3) * 20) + constrainInt(0, 0, 19)));
      dprint(serial_lcd, "Pion A1");
      // Remettre P1 a 0
      low(1);
    }
    else {
      // Effacer l'ecran sinon
      writeChar(serial_lcd, 12);
      pause(5);
    }

  }

}
